const mysqln = require('../config/db_connection')
module.exports.changeOrderStatus = async (req, res) => {
  try {
    //'H-47482e33a7d9db5b2c'
    const { value,type } = req.body 
    let sql,result;
    if(!value || value==undefined)
    {
      return res.status(400).json({
       
      message:"value is must"
      });
    }
    if(type=='Order') {
       sql = "select * from tbl_invoicedata where orderNo=?"
       result = await mysqln(sql,[value])
    } else {
       sql = "select * from tbl_invoicedata where	awbNumber=?"
       result = await mysqln(sql,[value])
    }


    if(result.length==0) {
      return res.status(201).json({
       message : "Order not Found"
      });
    }
    
    let deliveryDate = result[0].transactionInvoiceCreatedOn;
    const [datePart, timePart] = deliveryDate.split(" ");
    const [day, month, year] = datePart.split("-");
    const targetDate = new Date(`${year}-${month}-${day}T00:00:00`);
    const currentDate = new Date();
    const diffTime = currentDate.getTime() - targetDate.getTime()



    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    let status = "";
    let city="";
    let OutDelivery="";
    let Delivered=""
    if (diffDays >= 1 && diffDays < 2) {
      status = "Ordered";
      city = "";
      OutDelivery=""
      Delivered="";
    } else if ((diffDays >= 2 || diffDays >= 3) && (diffDays < 3 || diffDays < 4)) {
      status = "Shipped";
      city = "";
      OutDelivery=""
      Delivered="";
    } else if (diffDays >= 4 && diffDays < 5) {
      status = "Warehouse";
      city=result[0].city;
      OutDelivery=""
      Delivered="";
    } else if (diffDays >= 5 && diffDays < 6) {
      status = "Out-Delivery";
      city=result[0].city;
      OutDelivery=result[0].city;
      Delivered="";
    } else if (diffDays >= 6) {
      status = "Delivered";

      city=result[0].city;
      OutDelivery=result[0].city;
      Delivered=result[0].city;

    } else {
      status = "No status available for the given date.";
    }

    if(result.length>0) {
      return res.status(200).json({
        current_date: currentDate.toISOString().split("T")[0],
        status,
        city,
        OutDelivery,
        Delivered,
        result: result[0]
      });
    } 
  } catch (error) {
    res.status(500).json({ success: false, message: "Internal Server Error" });
  }
};

