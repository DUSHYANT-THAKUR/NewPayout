

const express = require('express');
const app = express();
const port = 9240;
const config = require('./config/config.js');
const cors = require("cors");


app.use(express.urlencoded({ extended: true })); // For parsing URL-encoded data (form data)
app.use(express.json()); // For parsing JSON data
app.use(cors())  



// routing
app.use(express.static('Public/E-signature'))
app.use(require('./routeInvoice/route.js'));

// run website
app.listen(port, (req, res) =>{
    console.log('http://' + config.DB_HOST + ':' + port);
});


