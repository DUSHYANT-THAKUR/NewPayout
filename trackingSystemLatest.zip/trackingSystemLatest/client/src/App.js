import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ContextProvider from "./context/ContextProvider"; // Import ContextProvider
import Home from "./Pages/Home";
import Track from "./Pages/Track";
import About from "./Pages/About";
import ContactUs from "./Pages/ContactUs";

function App() {
  return (
    <ContextProvider> {/* Ensure ContextProvider wraps everything */}
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/trackItem" element={<Track />} />
          <Route path = "/contact" element={<ContactUs />} />
          <Route path = "/about" element={<About />} />
        </Routes>
      </BrowserRouter>
    </ContextProvider>
  );
}

export default App;







 /* Home page Css Start*/
//  .banner-container {
//   position: relative;
//   display: flex;
//   justify-content: center;
//   align-items: center;
//   flex-direction: column;
//   padding: 2rem;
//   text-align: center;
//   overflow: hidden;
// }
// .banner-container img {
//   max-width: 100%;
//   height: auto;
//   margin-top: 30%;
// }
// .banner-overlay {
//   position: absolute;
//   top: 20%;
//   left: 50%;
//   transform: translate(-50%, -50%);
//   text-align: center;
//   z-index: 1;
// }
// .banner-heading {
//   font-size: 2.8rem;
//   font-weight: bold;
//   text-shadow: 2px 4px 6px rgba(0, 0, 0, 0.5);
//   margin-bottom: 0.5rem;
// }
// .banner-subtitle {
//   font-size: 1.4rem;
//   line-height: 1.5;
//   margin-top: 1rem;
// }
// .form-container {
//   display: flex;
//   align-items: center;
//   flex-direction: column;
// }
// .form-wrapper {
//   height: 400px;
//   width: 440px;
//   background: white;
//   border-radius: 1.5rem;
//   padding: 2.5rem;
//   box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 15px;
//   transition: all 0.3s ease-in-out;
// }
// .form-wrapper:hover {
//   transform: translateY(-5px);
//   box-shadow: rgba(0, 0, 0, 0.2) 0px 10px 20px;
// }
// .form-title {
//   font-size: 2rem;
//   font-weight: bold;
//   color: #4a4a4a;
// }
// .form-subtitle {
//   font-size: 1rem;
//   color: #6c757d;
//   margin-bottom: 1rem;
// }
// .input-box {
//   height: 50px;
//   border-radius: 8px;
//   border: 1px solid #ddd;
// }
// .my-submit-button {
//   width: 100%;
//   padding: 0.8rem;
//   font-size: 1rem;
//   background: #404040;
//   color: white;
//   border: none;
//   border-radius: 0.5rem;
//   transition: all 0.3s ease-in-out;
// }
// .features-section {
//   margin-top: 2rem;
// }
// .features-title {
//   font-size: 1.5rem;
//   font-weight: bold;
//   color: #333;
// }
// .feature-icons {
//   gap: 2rem;
// }
// .feature {
//   text-align: center;
// }
// .feature-icon {
//   font-size: 2.5rem;
//   color: #404040;
//   margin-bottom: 0.5rem;
// }
// .link-text {
//   color: #2575fc;
//   font-weight: bold;
//   text-decoration: none;
// }
// .link-text:hover {
//   text-decoration: underline;
// }
// .btn-group {
//   height: 50px;
// }
// .login-container {
//   background: linear-gradient(120deg, #f3f4f6, #eef2f3);
//   /* position: fixed; */
// }

// /* Loader Page css Start */
// .loader {
//   width: 100px;  
//   height: 100px;  
//   aspect-ratio: 1;
//   --_g: no-repeat radial-gradient(farthest-side, #181717 94%, #2b0ee900);
//   background:
//     var(--_g) 0 0,
//     var(--_g) 100% 0,
//     var(--_g) 100% 100%,
//     var(--_g) 0 100%;
//   background-size: 40% 40%;
//   animation: l38 0.5s infinite;
// }
// @keyframes l38 {
//   100% {
//     background-position: 100% 0, 100% 100%, 0 100%, 0 0;
//   }
// }
// .loader-text {
//   font-size: larger;
//   font-weight: 500;
//   letter-spacing: 1px;
//   font-style: italic;
//   text-shadow: 1px 1px blueviolet;
// }

// /* Tracking page css Start*/
// .container {
//   margin-top: 50px;
//   margin-bottom: 50px;
//   height: 100vh;
// }
// .card {
//   position: relative;
//   display: flex;
//   flex-direction: column;
//   min-width: 0;
//   word-wrap: break-word;
//   background-color: #fff;
//   background-clip: border-box;
//   border: 1px solid rgba(0, 0, 0, 0.1);
//   border-radius: 0.10rem;
//   box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
//   padding: 15px;
// }
// .card-header {
//   padding: 1rem;
//   background-color: #f8f9fa;
//   font-size: 1.25rem;
//   font-weight: bold;
//   border-bottom: 1px solid rgba(0, 0, 0, 0.1);
// }
// .card-body {
//   padding: 1.5rem;
// }
// h6 {
//   font-size: 1.1rem;
//   color: #333;
// }
// .track {
//   position: relative;
//   background-color: #ddd;
//   height: 7px;
//   display: flex;
//   margin-bottom: 60px;
//   margin-top: 50px;
// }
// .track .step {
//   flex-grow: 1;
//   width: 25%;
//   margin-top: -18px;
//   text-align: center;
//   position: relative;
// }
// .track .step::before {
//   height: 7px;
//   position: absolute;
//   content: "";
//   width: 100%;
//   left: 0;
//   top: 18px;
//   background-color: #ddd;
// }
// .track .step.active::before {
//   background: green;
// }
// .track .icon {
//   display: inline-block;
//   width: 40px;
//   height: 40px;
//   line-height: 40px;
//   position: relative;
//   border-radius: 100%;
//   background: #ddd;
// }
// .track .step.active .icon {
//   background: green;
//   color: #fff;
// }
// .track .step.completed .icon {
//   background: #4caf50;
//   color: #fff;
// }
// .track .text {
//   display: block;
//   margin-top: 7px;
//   font-size: 0.9rem;
//   color: #666;
// }
// .track .step.active .text {
//   font-weight: 600;
//   color: #333;
// }
// .itemside {
//   position: relative;
//   display: flex;
//   width: 100%;
// }
// .itemside .aside {
//   position: relative;
//   flex-shrink: 0;
// }
// .img-sm {
//   width: 80px;
//   height: 80px;
//   padding: 7px;
//   border-radius: 5px;
// }
// ul.row,
// ul.row-sm {
//   list-style: none;
//   padding: 0;
//   margin: 0;
// }
// .itemside .info {
//   padding-left: 15px;
//   padding-right: 7px;
// }
// .itemside .title {
//   display: block;
//   margin-bottom: 5px;
//   color: #212529;
//   font-weight: 600;
// }
// .itemside .title:hover {
//   color: #ee5435;
// }
// .itemside .text-muted {
//   color: #6c757d;
// }
// .btn-warning {
//   color: #ffffff;
//   background-color: #ee5435;
//   border-color: #ee5435;
//   border-radius: 1px;
//   padding: 10px 20px;
//   font-size: 1rem;
//   transition: background-color 0.3s ease;
// }
// .btn-warning:hover {
//   background-color: #ff2b00;
//   border-color: #ff2b00;
// }
// hr {
//   margin-top: 30px;
//   margin-bottom: 30px;
//   border-top: 1px solid #ddd;
// }

// /* Contact uS CSS */
// /* Contact Us Page Styles */
// .contact-container {
// /* background: rgb(190, 190, 255); */
// background: linear-gradient(120deg, #f3f4f6, #eef2f3);
// height: 100vh;
// display: flex;
// align-items: center;
// justify-content: center;
// padding: 20px;
// }

// /* Left Side (Image Section) */
// .contact-image {
// height: 80%;
// width: 100%;
// padding-top: 5%;
// }

// /* Right Side (Form Section) */
// /* Contact Us Page Styles */
// .contact-container {
// /* background: linear-gradient(135deg, #a3d8ff, #6b73ff); */
// height: 100vh;
// display: flex;
// align-items: center;
// justify-content: center;
// padding: 20px;
// }

// /* Left Side (Image Section) */
// .contact-image {
// height: 80%;
// width: 100%;
// padding-top: 5%;
// }

// /* Right Side (Form Section) */
// .form-container-contact {
// background: rgba(255, 255, 255, 0.15); /* Glassmorphism Effect */
// box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1); 
// backdrop-filter: blur(10px);
// border: 2px solid rgba(255, 255, 255, 0.2);
// padding: 30px;
// border-radius: 16px;
// width: 900px;
// text-align: center;
// display: flex;
// flex-direction: column;
// align-items: center;
// gap: 15px;
// transition: transform 0.3s ease-in-out;
// }

// /* Hover Effect on Form */
// .form-container-contact:hover {
// transform: scale(1.03); /* Subtle zoom effect */
// }

// /* Input Fields */
// .text-field-contact {
// width: 100%;
// }

// .text-field-contact input {
// outline: none;
// border: none;
// padding: 12px;
// background: rgba(255, 255, 255, 0.3);
// width: 100%;
// border-radius: 25px;
// transition: all 0.3s ease-in-out;
// font-size: 16px;
// text-align: center;
// color: #333;
// font-weight: bold;
// box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
// }

// /* Focus Effect */
// .text-field-contact input:focus {
// background: rgba(255, 255, 255, 0.6);
// box-shadow: 0 0 12px rgba(0, 123, 255, 0.4);
// border: 2px solid #007bff;
// }

// /* Button Styling */
// .contact-btn {
// background: linear-gradient(135deg, #007bff, #4c8bff);
// color: white;
// padding: 14px 25px;
// width: 100%;
// border: none;
// border-radius: 30px;
// font-size: 18px;
// cursor: pointer;
// font-weight: bold;
// transition: all 0.3s ease-in-out;
// box-shadow: 0 4px 10px rgba(0, 91, 187, 0.3);
// }

// /* Hover Effect on Button */
// .contact-btn:hover {
// background: linear-gradient(135deg, #0056b3, #003d80);
// transform: translateY(-2px);
// box-shadow: 0 6px 12px rgba(0, 91, 187, 0.5);
// }

// /* Responsive Design */
// @media (max-width: 768px) {
// .row.p-0.m-0 {
//     flex-direction: column;
//     height: auto;
// }

// .col-6 {
//     width: 100%;
//     text-align: center;
// }

// .contact-image {
//     height: auto;
//     width: 80%;
//     margin: auto;
// }

// .form-container-contact {
//     width: 90%;
// }
// }

