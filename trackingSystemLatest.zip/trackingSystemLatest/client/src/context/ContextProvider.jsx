// context/ContextProvider.js
import React, { createContext, useContext, useState } from "react";
const StateContext = createContext();
function ContextProvider({ children }) {
const [data,setData] = useState([]);
const [status,setStatus] = useState('');
const [cityForWareHouse,setCityForWareHouse] = useState('');
const [cityForOutForDelivery,setCityForOutForDelivery] = useState('');
const [cityForDelivered,setCityForDelivered] = useState('');
  return (
    <StateContext.Provider
      value={{
        data,
        setData,
        status,
        setStatus,
        cityForWareHouse,
        setCityForWareHouse,
        cityForOutForDelivery,
        setCityForOutForDelivery,
        cityForDelivered,
        setCityForDelivered
      }}
    >
      {children}
    </StateContext.Provider>
  );
}
export default ContextProvider;
export const useStateContext = () => useContext(StateContext);
