import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import "../CommonCoponent/Navbar.css";
import logo from '../CommonCoponent/image/xlogo.png';
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div className="navbar">
      <Link to="/">
        <img src={logo} alt="" className="logo" height={50} />
      </Link>
      <ul className="navbar-menu text-white">
        <NavLink to="/" className={({ isActive }) => (isActive ? "active" : "")} style={{ textDecoration: "none", color: "white" }}>Home</NavLink>
        <NavLink to="/about" className={({ isActive }) => (isActive ? "active" : "")} style={{ textDecoration: "none", color: "white" }}>About</NavLink>
        <NavLink to="/contact" className={({ isActive }) => (isActive ? "active" : "")} style={{ textDecoration: "none", color: "white" }}>Contact</NavLink>
      </ul>
      <div className="navbar-right">
        <i className="fa-solid fa-location-dot text-white fs-2"></i>
      </div>
    </div>
  );
};

export default Navbar;
