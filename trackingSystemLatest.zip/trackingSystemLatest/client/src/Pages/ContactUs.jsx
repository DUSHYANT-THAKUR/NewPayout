import React from "react";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import PermPhoneMsgOutlinedIcon from "@mui/icons-material/PermPhoneMsgOutlined";
import AddLocationOutlinedIcon from "@mui/icons-material/AddLocationOutlined";
import aboutimg2 from "../Pages/Images/about-page-title-bg.jpg";
import Nav from "./CommonCoponent/nav";
import "../App.css";
function ContactUs() {
  return (
    <div className="contact-container">
      <div className="row m-0 p-0" style={{ backgroundColor: "black" }}>
        <div className="col-12">
          <Nav />
        </div>
      </div>
      {/* <div class="box"> */}
        {/* <div class="logo">
          <img src="https://image.ibb.co/new91k/logo.png" />
        </div> */}

      {/* </div> */}

      <div
        className="page-title dark-background"
        style={{ backgroundImage: `url(${aboutimg2})` }}
      >
        <div className="container text-white">
          <h1>Contact Us</h1>
          {/* <nav className="breadcrumbs">
            <ol>
              <li>
                <a href="/">Home</a>
              </li>
              <li className="current">contact</li>
            </ol>
          </nav> */}
        </div>
      </div>
      <div className="touch mt-5">
        <h2>Get in touch</h2>
        <hr
          className="redline"
          style={{ display: "flex", alignSelf: "center" }}
        />
      </div>
      <div className="contact-us-form-container mt-4">
        <div className="row">
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="First Name"
                ng-model="firstname"
                name="firstname"
                required
              />
            </div>
          </div>
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Last Name"
                ng-model="company"
                name="company"
                required
              />
            </div>
          </div>
        </div>
        <div className="row mt-2">
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Company Name"
                ng-model="firstname"
                name="firstname"
                required
              />
            </div>
          </div>
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="E-mail"
                ng-model="company"
                name="company"
                required
              />
            </div>
          </div>
        </div>
        <div className="row mt-2">
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Phone"
                ng-model="firstname"
                name="firstname"
                required
              />
            </div>
          </div>
          <div className="col-6">
            <div className="form-group">
              <input
                type="text"
                className="form-control"
                placeholder="Message Id"
                ng-model="company"
                name="company"
                required
              />
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12">
            <div className="form-group">
              <textarea
                className="form-control"
                placeholder="Message"
                ng-model="message"
                name="message"
                required
              ></textarea>
            </div>
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-12 text-center">
            <div className="pager">
              <button type="submit" className="btn btn-success">
                SEND MESSAGE
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="bottom-gap"></div>
      <div className="row mt-4 mb-5">
        <div
          className="col-lg-6 col-12"
          style={{ boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)" }}
        >
          <h3
            className="text-center mb-4"
            style={{ fontSize: "30px", fontWeight: "700", color: "#2c3e50" }}
          >
            Our Contact Information
          </h3>
          <div className="img-text-container mb-4">
            <div
              className="img-container"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "20px",
                borderRadius: "10px",
                backgroundColor: "#eaf4fc",
                boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                marginBottom: "20px",
              }}
            >
              <PermPhoneMsgOutlinedIcon
                style={{ height: "50px", width: "50px", color: "#28a745" }}
              />
              <div
                style={{
                  marginLeft: "15px",
                  fontWeight: "500",
                  color: "#333",
                  fontSize: "18px",
                }}
              >
                +91 8954342578
              </div>
            </div>
            {/* <div
        className="text-container"
        style={{
          textAlign: "center",
          fontSize: "16px",
          color: "#333",
          fontWeight: "600",
        }}
      >
        Phone Number
      </div> */}
          </div>
          <div className="img-text-container mb-4">
            <div
              className="img-container"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "20px",
                borderRadius: "10px",
                backgroundColor: "#eaf4fc",
                boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                marginBottom: "20px",
              }}
            >
              <EmailOutlinedIcon
                style={{ height: "50px", width: "50px", color: "#007bff" }}
              />
              <div
                style={{
                  marginLeft: "15px",
                  fontWeight: "500",
                  color: "#333",
                  fontSize: "18px",
                }}
              >
                support@xpresslogi.com
              </div>
            </div>
            {/* <div
        className="text-container"
        style={{
          textAlign: "center",
          fontSize: "16px",
          color: "#333",
          fontWeight: "600",
        }}
      >
        Email Address
      </div> */}
          </div>

          <div className="img-text-container mb-4">
            <div
              className="img-container"
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "20px",
                borderRadius: "10px",
                backgroundColor: "#eaf4fc",
                boxShadow: "0 4px 8px rgba(0,0,0,0.1)",
                marginBottom: "20px",
              }}
            >
              <AddLocationOutlinedIcon
                style={{ height: "50px", width: "50px", color: "#f39c12" }}
              />
              <div
                style={{
                  marginLeft: "15px",
                  fontWeight: "500",
                  color: "#333",
                  fontSize: "18px",
                }}
              >
                KH. N0-806/1, Ground Floor, Mahipalpur, South West Delhi, Delhi,
                110037
              </div>
            </div>
            {/* <div
        className="text-container"
        style={{
          textAlign: "center",
          fontSize: "16px",
          color: "#333",
          fontWeight: "600",
        }}
      >
        Office Location
      </div> */}
          </div>
        </div>

        <div className="col-lg-6 col-12">
          <div
            className="map-container p-2"
            style={{
              position: "relative",
              height: "450px",
              borderRadius: "10px",
              boxShadow: "0 4px 12px rgba(0, 0, 0, 0.1)", // Apply box shadow here as well
            }}
          >
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14018.80027243419!2d77.12496179709656!3d28.548733610148304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1c1514f5a741%3A0x545ffeef6b14c5aa!2sMahipalpur%2C%20New%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1740729125459!5m2!1sen!2sin"
              width="100%"
              height="100%"
              frameBorder="0"
              style={{ border: "0", borderRadius: "10px" }}
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
      <div
        className="row pb-5 pt-5 mt-5"
        style={{ backgroundColor: "black", padding: "20px 0" }}
      >
        <div className="col-12 text-white text-center">
          <p style={{ margin: "0", fontSize: "16px" }}>
            &copy; {new Date().getFullYear()} <strong>XpressLogi</strong>. All
            rights reserved.
          </p>
          <p style={{ fontSize: "14px", margin: "5px 0" }}>
            This website and its content are protected by copyright law.
            Unauthorized use, reproduction, or distribution of any material is
            prohibited.
          </p>
          <div>
            <a
              href="/terms"
              style={{
                color: "lightgray",
                textDecoration: "none",
                marginRight: "15px",
              }}
            >
              Terms of Service
            </a>
            <a
              href="/privacy"
              style={{ color: "lightgray", textDecoration: "none" }}
            >
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
export default ContactUs;
