import React, { useState } from "react";
import loginBackground from "./Images/login-background-img.png";
import locationPic from "./Images/loction-pic.png";
import CapchaImg from "./Images/captcha.png";
import { ButtonGroup, Button, CircularProgress } from "@mui/material";
import axios from "axios";
import baseUrl from "./config/baseUrl";
import "bootstrap/dist/css/bootstrap.min.css";
import "../App.css";
import { useNavigate, Link } from "react-router-dom";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import Slide from "@mui/material/Slide";
import { useStateContext } from "../context/ContextProvider";
import CancelOutlinedIcon from "@mui/icons-material/CancelOutlined";
import Nav from "./CommonCoponent/nav";
import Navbar from "./CommonCoponent/nav";

function Home() {
  const [activeButton, setActiveButton] = useState("AWB");
  const [value, setValue] = useState("");
  const [open, setOpen] = React.useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [verified, setVerified] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const {
    setData,
    setStatus,
    setCityForWareHouse,
    setCityForOutForDelivery,
    setCityForDelivered,
  } = useStateContext();
  const navigate = useNavigate();
  const handleButtonClick = (button) => {
    setActiveButton(button);
  };
  const handleClose = () => {
    setOpen(false);
    setMessage("");
    setLoading(false);
    window.location.reload();
  };
  const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
  });
  const handleVerification = () => {
    setIsVerifying(true);
    setProgress(0);

    let progressInterval = setInterval(() => {
      setProgress((oldProgress) => {
        if (oldProgress >= 100) {
          clearInterval(progressInterval);
          setVerified(true); // Checkbox will be checked after 2 seconds
          setIsVerifying(false); // Hide the progress bar
          return 100;
        }
        return oldProgress + 50; // Progress bar fills in 2 seconds
      });
    }, 500);
  };

  const handleSubmit = async (e) => {
    if (!verified) {
      alert("Please check the 'I am not a robot' checkbox.");
      return; // Stop submission
    }
    e.preventDefault();
    setLoading(true); // Show the loader
    setMessage(""); // Clear any previous message
    setOpen(true); // Ensure the dialog stays open during the process
    let formData = new FormData();
    formData.append("value", value);
    formData.append("type", activeButton);
    const config = {
      headers: {
        "Content-type": "application/json",
        Accept: "application/json",
      },
    };
    try {
      let result = await axios.post(
        `${baseUrl}/changeOrderStatus`,
        formData,
        config
      );
      setData(result.data.result);
      setStatus(result.data.status);
      setCityForWareHouse(result.data.city);
      setCityForOutForDelivery(result.data.OutDelivery);
      setCityForDelivered(result.data.Delivered);
      localStorage.setItem("value", value);
      localStorage.setItem("type", activeButton);
      // Simulate a delay for the loader (minimum of 2 seconds)
      const minimumLoaderTime = new Promise((resolve) =>
        setTimeout(resolve, 4000)
      );
      await minimumLoaderTime;
      console.log("my result is", result);
      if (result.status === 200) {
        setLoading(false); // Stop the loader
        setOpen(false); // Close the dialog
        navigate("/trackItem");
      } else {
        await minimumLoaderTime; // Wait for 2 seconds
        setLoading(false); // Stop the loader
        setMessage("No data found for the provided Number.");
      }
    } catch (error) {
      setLoading(false); // Stop the loader in case of an error
      setMessage("An error occurred. Please try again later.");
      console.error("Error in submitting data:", error);
    }
  };
  return (
    <div className="login-container">
      <div className="row m-0 p-0" style={{ backgroundColor: "black" }}>
        <div className="col-12">
          <Navbar />
        </div>
      </div>
      <div className="row gx-0" style={{ marginRight: 0 }}>
        {/* Left Banner Section */}
        <div className="col-lg-6  banner-container mt-4">
          <img src={loginBackground} alt="Track Your Orders" />
          <div className="banner-overlay">
            <h2 className="banner-heading">Your Package, Our Priority</h2>
            <p className="banner-subtitle">
              Stay connected to your shipments like never before.
            </p>
          </div>
        </div>
        {/* Right Section */}
        <div className="col-lg-6  form-container mt-4">
          <div className="row" style={{ marginRight: 0 }}>
            <div className="col-12">
              <img
                src={locationPic}
                alt="image"
                style={{ height: "140px", width: "200px" }}
              />
            </div>
          </div>
          <div className="form-wrapper sign-in-form-wrapper">
            <div className="text-center">
              <h1 className="form-title">Track Your Order</h1>
              <p className="form-subtitle">
                Get real-time updates on your shipment.
              </p>
            </div>
            <div className="row" style={{ marginRight: 0 }}>
              <div className="col-12">
                <ButtonGroup
                  variant="outlined"
                  aria-label="device button group"
                  className="mt-2 btn-group"
                  sx={{
                    display: "flex",
                    flexWrap: "wrap", // Ensures buttons wrap on small screens
                    justifyContent: "center",
                    gap: "10px", // Adds spacing between buttons
                  }}
                >
                  <Button
                    variant={activeButton === "AWB" ? "contained" : "outlined"}
                    onClick={() => handleButtonClick("AWB")}
                    sx={{
                      minWidth: "150px", // Allows shrinking
                      flex: "1 1 auto", // Makes buttons flexible
                      backgroundColor:
                        activeButton === "AWB" ? "#404040" : "transparent",
                      color: activeButton === "AWB" ? "white" : "#404040",
                      borderColor: "black",
                      "&:hover": {
                        backgroundColor:
                          activeButton === "AWB"
                            ? "#333"
                            : "rgba(0, 0, 0, 0.1)",
                      },
                    }}
                  >
                    AWB Number
                  </Button>
                  <Button
                    variant={
                      activeButton === "Order" ? "contained" : "outlined"
                    }
                    onClick={() => handleButtonClick("Order")}
                    sx={{
                      minWidth: "150px",
                      flex: "1 1 auto",
                      backgroundColor:
                        activeButton === "Order" ? "#404040" : "transparent",
                      color: activeButton === "Order" ? "white" : "#404040",
                      borderColor: "black",
                      "&:hover": {
                        backgroundColor:
                          activeButton === "Order"
                            ? "#333"
                            : "rgba(0, 0, 0, 0.1)",
                      },
                    }}
                  >
                    Order Number
                  </Button>
                </ButtonGroup>
              </div>
            </div>

            {/* Form */}
            <form
              className="form sign-in-form"
              onSubmit={(e) => handleSubmit(e)}
            >
              <div className="input-field mt-3">
                <input
                  type="text"
                  className="form-control input-box"
                  placeholder={"Enter " + activeButton + " Number"}
                  onChange={(e) => setValue(e.target.value)}
                  required
                />
              </div>
              <div className="robot-verification mt-2 shadow-lg bg-white p-3 d-flex align-items-center justify-content-center">
                <div className="row w-100 d-flex align-items-center text-center">
                  <div className="col-1 d-flex justify-content-center">
                    <label>
                      {!isVerifying ? (
                        <input
                          type="checkbox"
                          checked={verified}
                          onChange={(e) => {
                            if (!verified) {
                              handleVerification(e);
                            }
                          }}
                          style={{
                            transform: "scale(1.5)",
                            cursor: verified ? "not-allowed" : "pointer",
                            accentColor: "#1976D2",
                          }}
                        />
                      ) : (
                        <CircularProgress
                          variant="determinate"
                          value={progress}
                          size={24}
                        />
                      )}
                    </label>
                  </div>

                  <div className="col-7 d-flex align-items-center justify-content-start">
                    <span
                      className="ms-2"
                      style={{ fontStyle: "normal", fontWeight: 400 }}
                    >
                      I am Human
                    </span>
                  </div>

                  <div className="col-4 text-end ">
                    <Link to="https://www.hcaptcha.com/what-is-hcaptcha-about?ref=www.dtdc.in&utm_campaign=ee9a864a-d99a-4e54-a6ce-3aca989af9c6&utm_medium=checkbox'">
                      <img
                        src={CapchaImg}
                        alt="Robot"
                        style={{ height: "40px" }}
                      />
                    </Link>
                  </div>
                  <span className="ms-2 text-end" style={{ fontSize: "small" }}>
                    {" "}
                    hCaptcha
                  </span>
                </div>
              </div>

              <button type="submit" className="my-submit-button mt-2">
                Track Order
              </button>
              <p className="mt-3 text-center">
                Need Help?{" "}
                <Link to="/contact" className="link-text">
                  Contact Us
                </Link>
              </p>
            </form>
          </div>
          {/* Features Section */}
          <div className="features-section text-center mt-5">
            <h2 className="features-title">Why Choose Us?</h2>
            <div className="feature-icons d-flex justify-content-around mt-4">
              <div className="feature">
                <i className="fas fa-truck feature-icon"></i>
                <p>Fast Delivery</p>
              </div>
              <div className="feature">
                <i className="fas fa-map-marker-alt feature-icon"></i>
                <p>Real-Time Tracking</p>
              </div>
              <div className="feature">
                <i className="fas fa-lock feature-icon"></i>
                <p>Secure Service</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        className="row pb-5 pt-5 mt-5"
        style={{ backgroundColor: "black", padding: "20px 0", marginRight: 0 }}
      >
        <div className="col-12 text-white text-center">
          <p style={{ margin: "0", fontSize: "16px" }}>
            &copy; {new Date().getFullYear()} <strong>XpressLogi</strong>. All
            rights reserved.
          </p>
          <p style={{ fontSize: "14px", margin: "5px 0" }}>
            This website and its content are protected by copyright law.
            Unauthorized use, reproduction, or distribution of any material is
            prohibited.
          </p>
          <div>
            <a
              href="/terms"
              style={{
                color: "lightgray",
                textDecoration: "none",
                marginRight: "15px",
              }}
            >
              Terms of Service
            </a>
            <a
              href="/privacy"
              style={{ color: "lightgray", textDecoration: "none" }}
            >
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
      {/* Dialog with Loader */}
      <Dialog
        open={loading || message !== ""}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleClose} // This allows closing on outside click
        aria-describedby="alert-dialog-slide-description"
        PaperProps={{
          style: {
            width: "70%",
            maxWidth: "400px",
            height: "300px",
            borderRadius: "40px",
          },
        }}
      >
        {message !== "" ? (
          <DialogContent
            style={{
              display: "flex",
              flexDirection: "column",
              marginTop: "15px",
              alignItems: "center",
              height: "100%",
              textAlign: "center",
            }}
          >
            <CancelOutlinedIcon style={{ fontSize: "90px", color: "red" }} />
            <div
              style={{
                fontSize: "larger",
                fontWeight: "500",
                color: "red",
                marginTop: "5%",
              }}
            >
              {message}
            </div>
          </DialogContent>
        ) : (
          <DialogContent
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
              textAlign: "center",
            }}
          >
            <div className="loader"></div>
            <div style={{ marginTop: "60px" }}>
              <span className="loader-text">Searching... Please Wait</span>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </div>
  );
}
export default Home;
