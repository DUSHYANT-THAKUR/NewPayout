// import React from "react";
// import "../App.css"; // Import the CSS file
// import Nav from "../Pages/CommonCoponent/nav";
// import BannerAbout from "./Images/web-logo.png";
// import AboutUs from "./Images/about-us-card1.jpg";

// const About = () => {
//   return (
//     <>
//       <div>
//         <div>
//           <Nav />
//         </div>
//         {/* <nav className="custom-navbar"></nav> */}
//         <header>
//           <img
//             src="https://images.pexels.com/photos/5025669/pexels-photo-5025669.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
//             alt=""
//             style={{
//               width: "100%",
//               height: "500px",
//               objectFit: "cover",
//               objectPosition: "center",
//             }}
//           />
//         </header>
//         <div className="custom-container">
//           {/* About Section */}
//           <section className="custom-about">
//           <div className="custom-about-left">
//   <h1>About Us</h1>
//   <hr className="m-auto" />
//   <p>
//     Speed, efficiency, and reliability—these are the pillars of <strong>Xpresslogi</strong>.
//     We understand the importance of **on-time deliveries**, and that's why we've built a service
//     that ensures **lightning-fast** shipping with **real-time tracking** at your fingertips.
//   </p>
//   <p>
//     Whether you need to send **a package, food, or urgent documents**, our **dedicated fleet** and
//     **advanced logistics system** ensure a smooth and secure delivery.
//     **No delays, no worries—just fast and seamless service!**
//   </p>
// </div>

//             <div className="custom-about-right">
//               <img src={AboutUs} alt="About" />
//             </div>
//           </section>

//           {/* Mission Section */}
//           <section className="custom-mission">
//             <div className="custom-mission-left">
//               <img
//                 src="https://img.freepik.com/premium-photo/mission-business-concept-finacial-success-chart-concept-virtual-screen-abstract-business-background_161452-13148.jpg?w=1800"
//                 alt="Mission"
//               />
//             </div>
//             <div className="custom-mission-right">
//               <h1>Our Mission</h1>
//               <hr className="m-auto" />
//               <p>
//                 At <strong>Xpresslogi</strong>, our mission is to revolutionize
//                 **fast and reliable delivery** services. We are committed to
//                 ensuring that every package reaches its destination **safely,
//                 securely, and on time**.
//               </p>
//               <p>
//                 Through **cutting-edge technology, real-time tracking, and
//                 dedicated customer support**, we strive to provide a seamless
//                 and efficient delivery experience. Whether it's urgent
//                 shipments, business logistics, or personal parcels, we deliver
//                 with **speed, precision, and trust**.
//               </p>
//             </div>
//           </section>

//           {/* Team Section */}
//           <section className="custom-services">
//             <h1>Our Services</h1>
//             <hr className="m-auto" />
//             <div className="custom-services-grid">
//               {[
//                 {
//                   title: "Express Delivery",
//                   description:
//                     "Get your packages delivered within hours with our super-fast delivery network.",
//                   img: "https://img.freepik.com/premium-photo/fast-food-delivery-man-green-scooter-delivery-concept-online-order-food-delivery-last-mile-banner-template_99433-7137.jpg?w=1380",
//                 },
//                 {
//                   title: "Real-Time Tracking",
//                   description:
//                     "Track your shipments in real-time with our advanced GPS tracking system.",
//                   img: "https://img.freepik.com/free-vector/smartphone-mobile-navigation_1284-12708.jpg?t=st=1740739593~exp=1740743193~hmac=b3ebc3b0a927dbeb5cdd176d5c1bbdc94d097a0a9b5abd4a618911afc30f9d8d&w=1060",
//                 },
//                 {
//                   title: "Secure Packaging",
//                   description:
//                     "We ensure safe and secure packaging to protect your goods during transit.",
//                   img: "https://img.freepik.com/premium-vector/editable-design-icon-parcel-security_362714-11195.jpg?w=900",
//                 },
//                 {
//                   title: "24/7 Customer Support",
//                   description:
//                     "Our dedicated support team is available round the clock to assist you.",
//                   img: "https://img.freepik.com/free-vector/call-center-abstract-concept_335657-3001.jpg?t=st=1740739760~exp=1740743360~hmac=7f93fab9e13c5bb22897585692447ebbcd9eaf88e8a6d5ef73141931e4396917&w=900",
//                 },
//                 {
//                   title: "Eco-Friendly Deliveries",
//                   description:
//                     "We use sustainable packaging and fuel-efficient routes to reduce our carbon footprint.",
//                   img: "https://img.freepik.com/free-photo/portrait-delivery-man-handing-out-parcel_23-2149561233.jpg?t=st=1740739843~exp=1740743443~hmac=7fdb54f23f9bb2133ae6ab5f3de17ad28918f3807d0fc451d48314df47d0a150&w=1380",
//                 },
//                 {
//                   title: "Flexible Scheduling",
//                   description:
//                     "Choose a delivery time that suits your schedule with our flexible delivery options.",
//                   img: "https://img.freepik.com/free-photo/schedule-organization-planning-list-concept_53876-147954.jpg?t=st=1740739886~exp=1740743486~hmac=ce6d0de33ef8abbc8a73420d748b3f34f1f3f71959924bc1809dbef7a42683d6&w=1380",
//                 },
//               ].map((service, index) => (
//                 <div key={index} className="custom-service-card">
//                   <img src={service.img} alt={service.title} />
//                   <h2>{service.title}</h2>
//                   <p>{service.description}</p>
//                 </div>
//               ))}
//             </div>
//           </section>
//         </div>

//         <div
//           className="row pb-5 pt-5 mt-5"
//           style={{ backgroundColor: "black", padding: "20px 0" }}
//         >
//           <div className="col-12 text-white text-center">
//             <p style={{ margin: "0", fontSize: "16px" }}>
//               &copy; {new Date().getFullYear()} <strong>XpressLogi</strong>. All
//               rights reserved.
//             </p>
//             <p style={{ fontSize: "14px", margin: "5px 0" }}>
//               This website and its content are protected by copyright law.
//               Unauthorized use, reproduction, or distribution of any material is
//               prohibited.
//             </p>
//             <div>
//               <a
//                 href="/terms"
//                 style={{
//                   color: "lightgray",
//                   textDecoration: "none",
//                   marginRight: "15px",
//                 }}
//               >
//                 Terms of Service
//               </a>
//               <a
//                 href="/privacy"
//                 style={{ color: "lightgray", textDecoration: "none" }}
//               >
//                 Privacy Policy
//               </a>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default About;

import React from "react";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import aboutimg2 from "../Pages/Images/about-page-title-bg.jpg";
import ctabg from "../Pages/Images/cta-bg.jpg";
import aboutimg5 from "../Pages/Images/bike.jpg";
import aboutimg6 from "../Pages/Images/about-banner.avif";
import express from "../Pages/Images/express.avif";
import secure from "../Pages/Images/secure.avif";
import customer from "../Pages/Images/customer.avif";
import ecoFriendly from "../Pages/Images/ecofriendly.avif";
import schedule from "../Pages/Images/schedule.avif";
import fastdelivery from "../Pages/Images/fastdelivery2.jpg";
import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import Navbar from "./CommonCoponent/nav";

const About = () => {
  return (
    <main className="main">
      <div className="row m-0 p-0" style={{ backgroundColor: "black" }}>
        <div className="col-12">
          <Navbar />
        </div>
      </div>
      <div
        className="page-title dark-background image-outer"
        style={{ backgroundImage: `url(${aboutimg2})` }}
      >
        <div className="container text-white">
          <h1>About</h1>
          <nav className="breadcrumbs">
            <ol>
              <li>
                <a href="/">Home</a>
              </li>
              <li className="current">About</li>
            </ol>
          </nav>
        </div>
      </div>

      {/* About Section */}
      <section id="about" className="about section pt-5">
        <div className="container">
          <div className="row gy-4">
            <div className="col-lg-5">
              <img src={aboutimg6} className="img-fluid" alt="About" />
            </div>
            <div className="col-lg-7">
              <div className="content">
              <h3 className=" heading">🚀 Why Choose Xpresslogi?</h3>

                <hr className="m-auto pb-3" />
                <ul>
                  <li>
                  ✅ Speed, efficiency, and
                  reliability—the core principles of Xpresslogi.
                  </li>
                  <li>
                  ✅ Enjoy
                  real-time tracking for complete transparency.
                  </li>
                  <li>
                  ✅ Need to send a
                  package, food, or urgent documents? We've got you covered!
                  </li>
                  <li>
                  ✅ We prioritize
                  on-time deliveries, ensuring lightning-fast shipping.
                  </li>
                  <li>
                  ✅
                Our dedicated fleet and advanced logistics system guarantee
                smooth and secure delivery.
                  </li>
                  <li>
                  ✅ No delays, no worries—just fast
                  and seamless service!
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Us Section */}
      <section
        id="why-us"
        className="why-us section"
        style={{ padding: "60px 0px" }}
      >
        <div className="container">
          <div className="row g-0">
            <div
              class="col-xl-5 img-bg"
              data-aos="fade-up"
              data-aos-delay="100"
            >
              <img src={fastdelivery} alt="Why Us" />
            </div>
            <div className="col-xl-7 slides position-relative">
              <Swiper
                modules={[Navigation, Pagination, Autoplay]}
                loop={true}
                speed={600}
                autoplay={{ delay: 5000 }}
                slidesPerView="auto"
                centeredSlides={true}
                pagination={{ clickable: true }}
                navigation
              >
                {[1, 2, 3].map((slide, index) => (
                  <SwiperSlide key={index}>
                    <div className="item">
                      <h1>
                        {slide === 1 && "Reliable Delivery"}
                        {slide === 2 && "Real-Time Tracking"}
                        {slide === 3 && "24/7 Support"}
                      </h1>
                      <hr className="m-auto" />
                      <p>
                        {slide === 1 && (
                          <>
                            At <strong>Xpresslogi</strong>, our mission is to
                            revolutionize the delivery experience with reliable
                            and fast services. We are committed to ensuring
                            every package reaches its destination on time,
                            safely, and securely.
                          </>
                        )}
                        {slide === 2 && (
                          <>
                            We utilize cutting-edge technology and real-time
                            tracking to keep you connected to your shipments.
                            Our goal is to provide a seamless experience,
                            ensuring that no package is ever out of reach.
                          </>
                        )}
                        {slide === 3 && (
                          <>
                            With dedicated customer support and fast delivery
                            solutions, we guarantee the best service for both
                            urgent shipments and regular deliveries. At
                            Xpresslogi, your package is always our priority.
                          </>
                        )}
                      </p>
                    </div>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          </div>
        </div>
      </section>
      {/* call to action */}

      <section
        id="call-to-action"
        className="call-to-action section dark-background"
      >
        <img src={ctabg} alt="" />
        <div className="container">
          <div
            className="row justify-content-center"
            data-aos="zoom-in"
            data-aos-delay="100"
          >
            <div className="col-xl-10">
              <div className="text-center text-white">
                <h3>Get Your Package Delivered Today</h3>
                <p>
                  Ready to experience fast and reliable shipping like never
                  before? At <strong>Xpresslogi</strong>, we prioritize your
                  packages and ensure they reach their destination securely and
                  on time. Whether it's a personal parcel or business shipment,
                  our efficient service has you covered.
                </p>
                <a className="cta-btn" href="#">
                  Start Your Shipment Now
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* end */}

      {/* team member */}

      <section className="custom-services">
        <h1>Our Services</h1>
        <hr className="m-auto" />
        <div className="custom-services-grid">
          {[
            {
              title: "Express Delivery",
              description:
                "Get your packages delivered within hours with our super-fast delivery network.",
              img: express,
            },
            {
              title: "Real-Time Tracking",
              description:
                "Track your shipments in real-time with our advanced GPS tracking system.",
              img: "https://img.freepik.com/free-vector/smartphone-mobile-navigation_1284-12708.jpg?t=st=1740739593~exp=1740743193~hmac=b3ebc3b0a927dbeb5cdd176d5c1bbdc94d097a0a9b5abd4a618911afc30f9d8d&w=1060",
            },
            {
              title: "Secure Packaging",
              description:
                "We ensure safe and secure packaging to protect your goods during transit.",
              img: secure,
            },
            {
              title: "24/7 Customer Support",
              description:
                "Our dedicated support team is available round the clock to assist you.",
              img: customer,
            },
            {
              title: "Eco-Friendly Deliveries",
              description:
                "We use sustainable packaging and fuel-efficient routes to reduce our carbon footprint.",
              img: ecoFriendly,
            },
            {
              title: "Flexible Scheduling",
              description:
                "Choose a delivery time that suits your schedule with our flexible delivery options.",
              img: schedule,
            },
          ].map((service, index) => (
            <div key={index} className="custom-service-card">
              <img src={service.img} alt={service.title} />
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
          ))}
        </div>
      </section>
      {/* end team member */}
      {/* Footer Section */}
      <div
        className="row pb-5 pt-5 mt-5"
        style={{ backgroundColor: "black", padding: "20px 0" }}
      >
        <div className="col-12 text-white text-center">
          <p style={{ margin: "0", fontSize: "16px" }}>
            &copy; {new Date().getFullYear()} <strong>XpressLogi</strong>. All
            rights reserved.
          </p>
          <p style={{ fontSize: "14px", margin: "5px 0" }}>
            This website and its content are protected by copyright law.
            Unauthorized use, reproduction, or distribution of any material is
            prohibited.
          </p>
          <div>
            <a
              href="/terms"
              style={{
                color: "lightgray",
                textDecoration: "none",
                marginRight: "15px",
              }}
            >
              Terms of Service
            </a>
            <a
              href="/privacy"
              style={{ color: "lightgray", textDecoration: "none" }}
            >
              Privacy Policy
            </a>
          </div>
        </div>
      </div>
    </main>
  );
};

export default About;
