import React, { useEffect } from "react";
import "../App.css";
import { useStateContext } from "../context/ContextProvider";
import { Link,useNavigate } from "react-router-dom";
import baseUrl from "./config/baseUrl";
import axios from "axios";
function App() { 
  let value = localStorage.getItem("value")
  let activeButton = localStorage.getItem("activeButton")
  const {data,status,setData,setStatus,cityForWareHouse,cityForOutForDelivery,cityForDelivered} = useStateContext()
  const dateString = data?.deliveryDate; 
  const [deliveryday, deliveryMonth, deliveryYear] = dateString.split("-"); 
  const date = new Date();
  const currDay = date.getDate()<9?"0"+date.getDate():date.getDate();
  const currMonth = date.getMonth()<9?"0"+(date.getMonth()+1):date.getMonth();
  const currYear = date.getFullYear();
  console.log("Delivery",deliveryday,deliveryMonth,deliveryYear);
  console.log("current",currDay,currMonth,currYear);
  const getStepClass = (step) => {
    const steps = ["Ordered", "Shipped", "Warehouse", "Out-Delivery", "Delivered"];
    const currentStepIndex = steps.indexOf(status);
    const stepIndex = steps.indexOf(step);

    if (stepIndex < currentStepIndex) return "step active";
    if (stepIndex === currentStepIndex) return "step active";
    return "step";
  };
const removeLocalItem = () => {
  localStorage.clear();
};
// const fetchData = async () => {
//   let formData = new FormData();
//   formData.append("value", value);
//   formData.append("type",activeButton)
//   const config = {
//     headers: {
//       "Content-type": "application/json",
//       Accept: "application/json",
//     },
//   };
//   try {
//     let result = await axios.post(`${baseUrl}/changeOrderStatus`, formData, config);
//     setData(result.data.result);
//      setStatus(result.data.status);
//   } catch (error) {
//     console.error("Error in submitting data:", error);
//   }
// };
// useEffect(() => {
//  fetchData()
// }, []);

  return (
    <div className="container">
      <article className="card" >
        <header className="card-header">My Orders / Tracking</header>
        <div className="card-body">
          <h6><b>Order ID: </b>{data.orderNo}</h6>
          <article className="card">
            <div className="card-body row">
              <div className="col-12 col-md-3">
                <strong>Order Date:</strong>
                <br />{data.transactionInvoiceCreatedOn}
              </div>
              <div className="col-12 col-md-3">
                <strong>Estimated Delivery Date:</strong>
                <br />
                {dateString}
              </div>
              <div className="col-12 col-md-3">
                <strong>Status:</strong>
                <br />
                {status}
              </div>
              <div className="col-12 col-md-3">
                <strong>Tracking AWB:</strong>
                <br />{data.awbNumber}
              </div>
            </div>
          </article>
          <div className="row mt-2 mb-1">
            <div className="col-12">
              <strong>Customer Details</strong>
            </div>
          </div>
          <article className="card">
            <div className="card-body row">
              <div className="col-12 col-md-3">
              <strong>Customer Name:</strong>
                <br /><span className="text-capitalize">{data.fullName}</span>
              </div>
              <div className="col-12 col-md-3">
                <strong>Customer Phone:</strong>
                <br />
                {data.mobileNo}
              </div>
              <div className="col-12 col-md-3">
                <strong>Shipping Address:</strong>
                <br />
                <span className="text-capitalize">{data.billingAddress}</span>
              </div>
              <div className="col-12 col-md-3">
                <strong>Billing Address:</strong>
                <br /><span className="text-capitalize">{data.billingAddress}</span>
              </div>
            </div>
          </article>
          <div className="track" style={{ marginTop: "5%" }}>
            <div className={getStepClass("Ordered")}>
              <span className="icon">
                <i className="fa fa-check"></i>
              </span>
              <span className="text">Ordered</span>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>Noida</div>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>{data.transactionInvoiceCreatedOn}</div>
            </div>
            <div className={getStepClass("Shipped")}>
              <span className="icon">
                <i className="fa fa-user"></i>
              </span>
              <span className="text">Shipped</span>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>Noida</div>
            </div>
            <div className={getStepClass("Warehouse")}>
              <span className="icon">
              <i className="fa fa-box"></i>
              </span>
              <span className="text">Warehouse</span>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>{cityForWareHouse}</div>
            </div>
            <div className={getStepClass("Out-Delivery")}>
              <span className="icon">
                
                <i className="fa fa-truck"></i>
              </span>
              <span className="text">Out-Delivery</span>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>{cityForOutForDelivery}</div>
            </div>
            <div className={getStepClass("Delivered")}>
              <span className="icon">
                <i className="fa fa-box"></i>
              </span>
              <span className="text">Delivered</span>
              <div className="mt-2" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>{cityForDelivered}</div>
              <div className="mt-1" style={{ fontWeight: 700,fontFamily: "none",fontSize: "large",color:" #858585",textShadow: "0.2px 0.2px #1e1f1f"}}>{(deliveryday<=currDay && deliveryYear<=currYear)?dateString:""}</div>
            </div>
          </div>
          <hr />
          <Link to="/" className="btn btn-warning" data-abc="true" style={{ marginTop: "5%" }} onClick={removeLocalItem}>
            <i className="fa fa-chevron-left"></i> Back to Home
          </Link>
        </div>
      </article>
    </div>
  );
}
export default App;
